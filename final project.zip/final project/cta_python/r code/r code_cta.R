################################## CTA Crime Analysis   ###############################

###############################  
#Performing Neccesary Pre-Processing
### PACKAGES THAT WILL BE USED 

install.packages("stringr")
install.packages("fastDummies")
install.packages("tidyverse")
install.packages("lubridate")
install.packages("dplyr")
install.packages("tidyr")
install.packages("corrplot")
install.packages('psych')
install.packages('rpart')
install.packages("pander")
install.packages("relaimpo")
install.packages("RColorBrewer")
install.packages('caret')
install.packages('Hmisc')

library(MASS)
library(PASWR2)
library(dplyr)
library(psych)
library(tidyverse)
library(lubridate)
library(dplyr)
library(tidyr)
library(reshape2)
library(scales)
library(forecast)
library(rpart)
library(zoo)
library(Hmisc)
library(tseries)
library(corrplot)
library(e1071)
library(pander)
library(ggplot2)
library(relaimpo)
library(RColorBrewer)
library(caret)
library(fastDummies)

#READING CTA FILE
data= read.csv("incident_training_042120.csv",header = TRUE)
data_test= read.csv("incident_testing_042120.csv",header = TRUE)
#Show Data
head(data)

data_cor=data("incident", "site_id","weekend","holiday","atm","restaurant","maxtemp","totalsnow","heatindex","cloudcover","Humidity","Temperature")
data3= sqrt(data$restaurant)
cor(data$incident,data3$restaurant)
data2=data[data_cor]
cor(data2)

cor(data[,unlist(lapply(data, is.numeric))])

#########################################
##3   Getting  very low correlaion value  with each incident##############################


nrow(data)
ncol(data)
dim(data)
typeof(data)
#Checking Missing Values
null_check = is.null(data)
null_check

#Performing Neccesary Pre-Processing
head(data)
############################################
ggplot(data=data,aes(x=data$week_day)) + 
  geom_bar(fill="blue") + 
  ggtitle("Day-wise distribution of crimes in various districts")
########################################################333



## Classification for Naive bayes 
## started working on pre processing for naive abyes 
#Setting outcome variables as categorical
### made an  copy of the dtaframe  named Data_nb
data_nb = data
data_nb=as.data.frame(data_nb)
head(data_nb)
## converted the response variable to true and false 
data_nb$incident <- factor(data_nb$incident, levels = c(0,1), labels = c("False", "True"))
data_test$incident <- factor(data_test$incident, levels = c(0,1), labels = c("False", "True"))
head(data_nb)
typeof(data_nb)
###structure of data
str(data_nb)
describe(data_nb)
##3 getting from describe that all the data do not have  missing values
#Data Visualization
#Visual 1
ggplot(data_nb, aes(data_nb$site_id, colour = incident)) +
  geom_freqpoly(binwidth = 2) + labs(title="CTA sites Distribution by incident")

### Checking the occurance ratio of incident in the training datat
prop.table(table(data_nb$incident)) * 100

###############################################################################




####Drooping attributes which can improve accuracy

data_nb$incident_type=NULL
data_test$incident_type=NULL
#### pRatice model building 
dim(data_nb)
x=data_nb[,-26]
y=data_nb$incident
head(data_nb)

library(e1071)
model_nb = train(x,y,'nb',trControl=trainControl(method='cv',number=10))
model_nb

###########################33
predict(model1,x)

#Model Evaluation###########################33
#Predict testing set
Predict <- predict(model1,newdata = data_test )
#Get the confusion matrix to see accuracy value and other parameter values

head(predict(model1,data_test,type="prob"))



confusionMatrix(Predict, data_test$incident)



#Plot Variable performance
X <- varImp(model1)
plot(X)


###########################################################################
str(data)
data_ex= data
is.factor(data_ex)

class(data_ex$incident)
data_ex$incident=cut(data_ex$incident,2)
as.factor(data_ex$incident)
####################################################################################3






