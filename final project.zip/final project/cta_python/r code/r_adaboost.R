
### packages for the emsembles 
install.packages("ada")
install.packages("dplyr")
library(dplyr)
library(ada)
install.packages("tree")
install.packages("randomForest")
library(randomForest)
library(tree)
basedata= read.csv("incident_training_042120.csv")
data_test= read.csv("incident_testing_042120.csv",header = TRUE)

#### Making  both incident_type to null in test and train data 

basedata$incident_type=NULL
data_test$incident_type=NULL

basedata$cta_sites=NULL
basedata$incident_date=NULL
basedata$sunset=NULL
basedata$sunrise=NULL
basedata$moonset=NULL

head(basedata)
#Categorical data
#week_day, time_category,moonset,weather_description



#numerical data

##site_id,weekend,holiday,atm,restaurant,avgtemp,maxtemp,totalsnaow,sunhour,moonrise,
#humidity,cloudover,heatindex,hrs after sunrise , hours after sunset

## traget variable 
## incident


install.packages("PCAmixdata")
library(PCAmixdata)
split <- splitmix(basedata)
X1 <- split$X.quanti() 
X2 <- split$X.quanti(Gives categorical columns in the dataset)





#Target Variable: Personal Loan
head(basedata)

num_data=data.frame(sapply(basedata[c('site_id','weekend','holiday','atm',)],function(x){as.numeric(x)}))


#'site_id','weekend','holiday','atm','restaurant','avgtemp','maxtemp','totalsnow','sunhour','moonrise','humidity','cloudcover','heatindex','hour_after_sunrise' ,'hours_to_sunset'

colnames(basedata)

x=basedata[,-26]
y=basedata$incident
x_test=data_test[,-26]
y_test=data_test$incident






head(basedata)


#Categorical data



summary(AdaObject)


ada(x,y,loss = "exponential",iter = 50)

############################################################################333
##Drop the variables
#head(basedata)
#basedata$site_id=NULL
#basedata$incident_date=NULL

#head(basedata)



basedata$incident <- factor(basedata$incident, levels = c(0,1), labels = c("False", "True"))
basedata$incident <- factor(basedata$incident, levels = c(0,1), labels = c("False", "True"))
str(basedata)
head(basedata)

#### tree method 
dim(basedata)




##3 model 

model_ada= ada(x,y,iter = 10,loss = "logistic")


### predict train data 
pred_data= predict(model_ada,x)
pred_data

### confusion matrix and accuracy
con_train=table(y,pred_data)
accuracy_train=sum(diag(con_train))/sum(con_train)
rm(pred_data,con_train)

######  predict on test data 

pred_test=predict(model_ada,x_test)
